

public class SortStarter
{
	public static void main(String[] args)
	{
		SortFrame frame = new SortFrame("Sorter");
	}
}